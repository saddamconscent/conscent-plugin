<?php

function conscent_enqueue_styles() {
    // Register the Bootstrap stylesheet
    wp_register_style('bootstrap-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css', array(), '1.0.0');
    
    // Enqueue the Bootstrap stylesheet
    wp_enqueue_style('bootstrap-css');
}

add_action('admin_enqueue_scripts', 'conscent_enqueue_styles');

function conscent_enqueue_scripts() {
    // Deregister the default jQuery included with WordPress
    wp_deregister_script('jquery');

    // Register jQuery from Google's CDN
    wp_register_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js', array(), '1.0.0', true);

    // Enqueue jQuery
    wp_enqueue_script('jquery');

    // Register Bootstrap's JavaScript
    wp_register_script('bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js', array('jquery'), '1.0.0', true);

    // Enqueue Bootstrap's JavaScript
    wp_enqueue_script('bootstrap-js');
}

add_action('admin_enqueue_scripts', 'conscent_enqueue_scripts');



if ( ! function_exists( 'conscent_settings_page' ) ) {

	function conscent_settings_page()

	{

	?>

	<div class="wrap">
		
		<div class="container">

			<h1><?php echo esc_html__( 'Conscent Setting', 'conscent-paywall' ); ?> </h1>

			<div class="row">

				<div class="col-8 col-md-8">

					<form method="post" action="options.php">

						<?php

							settings_fields("section");

							do_settings_sections("theme-options");      

							submit_button(); 

						?>          

					</form>

				</div>
			</div>

			<div class="col-8 col-md-8">

			<?php echo esc_html__( 'Add Login/Logout:-', 'conscent-paywall' ); ?> <b><?php echo esc_html('([ConscentLoginLogout])'); ?></b>

			<br>
				
			<?php echo esc_html__( 'Login User Name:-', 'conscent-paywall' ); ?> <b><?php echo esc_html('([userDetails key="name"])'); ?></b>

			<br>

			<?php echo esc_html__( 'Login User Email:-', 'conscent-paywall' ); ?><b><?php echo esc_html('([userDetails key="email"])'); ?></b>

			<br>

			<?php echo esc_html__( 'Login User Mobile No:-', 'conscent-paywall' ); ?><b><?php echo esc_html('([userDetails key="phone"])'); ?></b>

			<br>

			<?php echo esc_html__( 'Login User Subscriptions:-', 'conscent-paywall' ); ?><b><?php echo esc_html('([userDetails key="subscriptions"])'); ?></b>

			<br>

		</div>

	</div>

	</div>

	<?php

	}

}

if ( ! function_exists( 'conscent_theme_menu_item' ) ) {

	function conscent_theme_menu_item() {

		add_menu_page("Conscent Setting", "Conscent Setting", "manage_options", "conscent-paywall", "conscent_settings_page", null, 99);

	}

}

add_action("admin_menu", "conscent_theme_menu_item");


if ( ! function_exists( 'conscent_clientId1_element' ) ) {

	function conscent_clientId1_element() {

	?>

	<input type="text"  class="form-control" name="clientId1" id="clientId1" value="<?php echo esc_attr( get_option('clientId1') ); ?>" />

		<?php

	}

}

if ( ! function_exists( 'conscent_sdk_element' ) ) {

	function conscent_sdk_element() {

		?>

	<input type="text" class="form-control" name="sdkURL" id="sdkURL" value="<?php echo esc_attr( get_option('sdkURL') ); ?>" />

	<p><b><?php echo esc_url( 'https://conscent-sdk-v2-sandbox.netlify.app/csc-sdk.js' ); ?> </b>|<b> <?php echo esc_url( 'https://sdk-v2.conscent.in/csc-sdk.js' ); ?></b></p>

		<?php

	}

}

if ( ! function_exists( 'conscent_paywall_element' ) ) {

	function conscent_paywall_element() {
	?>

	<select  class="form-control" name="Paywall" id="Paywall">
		<option value=""><?php echo esc_html__( 'Select options', 'conscent-paywall' ); ?></option>
		<?php 
		$categories = get_categories(); 
		foreach ($categories as $category) {
			$option_value = esc_attr($category->term_id);
			$option_text = esc_html($category->cat_name . ' (' . $category->category_count . ')');
			$selected = ($category->term_id == get_option('Paywall')) ? 'selected="selected"' : '';
		?>
			<option value="<?php echo esc_attr( $option_value ); ?>" <?php echo esc_attr( $selected ); ?>>
				<?php echo esc_html( $option_text ); ?>
			</option>
		<?php } ?>

		</select>
	<?php

	}

}

if ( ! function_exists( 'conscent_api_url_element' ) ) {

	function conscent_api_url_element() {
	?>

	<input type="text" class="form-control" name="CONSCENT_API_URL" id="CONSCENT_API_URL" value="<?php echo esc_attr(get_option('CONSCENT_API_URL')); ?>" />

	<p><b><?php echo esc_url( 'https://sandbox-api.conscent.in/api/v2' ); ?></b> | <b> <?php echo esc_url( 'https://api.conscent.in/api/v2' ); ?></b></p>

	<?php

	}

}

if ( ! function_exists( 'conscent_api_key_element' ) ) {

	function conscent_api_key_element() {

	?>

		<input type="text" class="form-control" name="CONSCENT_API_KEY" id="CONSCENT_API_KEY" value="<?php echo esc_attr( get_option('CONSCENT_API_KEY') ); ?>" />

		<?php

	}

}

if ( ! function_exists( 'conscent_api_secret_element' ) ) {

	function conscent_api_secret_element() {

	?>

	<input type="text" class="form-control" name="CONSCENT_API_SECRET" id="CONSCENT_API_SECRET" value="<?php echo esc_attr( get_option('CONSCENT_API_SECRET') ); ?>" />

	<p></p>

	<?php

	}

}

if ( ! function_exists( 'conscent_after_logout_element' ) ) {

	function conscent_after_logout_element() {

	?>

		<input type="text" class="form-control" name="AfterLogout" id="AfterLogout" value="<?php echo esc_attr( get_option('AfterLogout') ); ?>" />

	<?php

	}

}

if ( ! function_exists( 'conscent_after_login_redirect_element' ) ) {

	function conscent_after_login_redirect_element() {

	?>

		<input type="text"  class="form-control" name="AfterLogin" id="AfterLogin" value="<?php echo esc_attr( get_option('AfterLogin') ); ?>" />

		<?php

	}

}

if ( ! function_exists( 'conscent_theam_location_element' ) ) {

	function conscent_theam_location_element() {

		// Get the locations dropdown
		echo '<select class="form-control" name="TheamLocation" id="TheamLocation">
				<option value="">Select Theme Location</option>';
		
		$theme_locations = get_nav_menu_locations();
		foreach ($theme_locations as $theme_location => $menu_id) {
			$selected = "";
			if(get_option('TheamLocation') == $theme_location) 
				$selected = ' selected="selected"';
			echo '<option value="' . esc_html($theme_location) . '" ' . esc_html($selected) . ' >' . esc_html($theme_location) . '</option>';
		}
		echo '</select>';
		
	}
	
}


if ( ! function_exists( 'conscent_content_visibility_element' ) ) {

	function conscent_content_visibility_element() {

	?>

		<input type="text"  class="form-control" name="ContentVisibility" id="ContentVisibility" value="<?php echo esc_attr( get_option('ContentVisibility') ); ?>" />

		<p><b><?php echo esc_html( 'Number of paragraph to be visible in locked content' ); ?></b></p>

	<?php

	}

}

if ( ! function_exists( 'conscent_default_name_element' ) ) {

	function conscent_default_name_element() {

	?>

		<select class="form-control" name="DefaultName" id="DefaultName">

			<option value="0" <?php if (get_option('DefaultName') == '0') echo ' selected="selected"'; ?>><?php echo esc_html__( 'Select Option', 'conscent-paywall' ); ?></option>
			
			<option value="1" <?php if (get_option('DefaultName') == '1') echo ' selected="selected"'; ?>><?php echo esc_html__( 'User Name', 'conscent-paywall' ); ?></option>

			<option value="2" <?php if (get_option('DefaultName') == '2') echo ' selected="selected"'; ?>><?php echo esc_html__( 'User Mobile', 'conscent-paywall' ); ?></option>

			<option value="3" <?php if (get_option('DefaultName') == '3') echo ' selected="selected"'; ?>><?php echo esc_html__( 'User Email ID', 'conscent-paywall' ); ?></option>

		</select>

	<?php

	}

}

if( ! function_exists( 'conscent_amp_sdk_url_element' ) ) {

	function conscent_amp_sdk_url_element () {
 
?>
		<input type="text" class="form-control" name="conscent_amp_sdk_url" id="conscent_amp_sdk_url" value="<?php echo esc_attr( get_option('conscent_amp_sdk_url') ); ?>" />

		<p><b><?php echo esc_url( 'https://v2-amp-sdk-sandbox.netlify.app' ); ?></b> | <b> <?php echo esc_url( 'https://sdk-amp-v2.conscent.in/csc-sdk.js' ); ?></b></p>

<?php

	}

}

if( ! function_exists( 'conscent_amp_api_url_element' ) ) {

	function conscent_amp_api_url_element () {
 
?>
		<input type="text" class="form-control" name="conscent_amp_api_url" id="conscent_amp_api_url" value="<?php echo esc_attr( get_option('conscent_amp_api_url') ); ?>" />

		<p><b><?php echo esc_url( 'https://sandbox-api.conscent.in/api/v2' ); ?></b> | <b> <?php echo esc_url( 'https://api.conscent.in/api/v2' ); ?></b></p>

<?php

	}

}

if ( ! function_exists( 'conscent_theme_panel_fields' ) ) {

	function conscent_theme_panel_fields() {

		add_settings_section("section", "All Settings", null, "theme-options");

		add_settings_field("clientId1", "Conscent Client Id", "conscent_clientId1_element", "theme-options", "section");

		add_settings_field("CONSCENT_API_KEY", "Conscent API Key <br>(Sandbox OR Live)", "conscent_api_key_element", "theme-options", "section");

		add_settings_field("CONSCENT_API_SECRET", "Conscent API Secret (Sandbox OR Live)", "conscent_api_secret_element", "theme-options", "section");

		add_settings_field("sdkURL", "Conscent SDK URL (Sandbox OR Live)", "conscent_sdk_element", "theme-options", "section");
		
		add_settings_field("CONSCENT_API_URL", "Conscent API URL (Sandbox OR Live)", "conscent_api_url_element", "theme-options", "section");

		add_settings_field("conscent_amp_sdk_url", "Conscent AMP SDK URL (Sandbox OR Live)", "conscent_amp_sdk_url_element", "theme-options", "section");
		
		add_settings_field("conscent_amp_api_url", "Conscent AMP API URL (Sandbox OR Live)", "conscent_amp_api_url_element", "theme-options", "section");

		add_settings_field("Paywall", "Paywall Category", "conscent_paywall_element", "theme-options", "section");

		add_settings_field("AfterLogout", "After Logout Redirect", "conscent_after_logout_element", "theme-options", "section");

		add_settings_field("AfterLogin",  "After Login Redirect", "conscent_after_login_redirect_element", "theme-options", "section");

		add_settings_field("TheamLocation","Theme Location Name", "conscent_theam_location_element", "theme-options", "section");
		
		add_settings_field("ContentVisibility","Content Visibility", "conscent_content_visibility_element", "theme-options", "section");

		add_settings_field("DefaultName","DefaultName", "conscent_default_name_element", "theme-options", "section");

		add_settings_section("section", "All Settings",null,"theme-options");

		register_setting("section", "Paywall");

		register_setting("section", "clientId1");
		
		register_setting("section", "CONSCENT_API_KEY");

		register_setting("section", "CONSCENT_API_SECRET");

		register_setting("section", "sdkURL");

		register_setting("section", "CONSCENT_API_URL");

		register_setting("section", "conscent_amp_sdk_url");
		
		register_setting("section", "conscent_amp_api_url");

		register_setting("section", "AfterLogout");

		register_setting("section", "AfterLogin");

		register_setting("section", "TheamLocation");

		register_setting("section", "ContentVisibility");

		register_setting("section", "DefaultName");

	}

}

add_action("admin_init", "conscent_theme_panel_fields");