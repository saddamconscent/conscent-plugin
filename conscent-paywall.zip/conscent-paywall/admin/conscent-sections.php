<?php
if ( ! function_exists( 'member_meta_box_callback' ) ) {

	function conscent_register_taxonomy_sections() {
		$labels = array('name' => _x('Sections', 'taxonomy general name'),
		'singular_name' => _x('Sections', 'taxonomy singular name'),
		'search_items' => __('Search Sections'),
		'all_items' => __('All Sections'),
		'parent_item' => __('Parent Sections'), 
		'parent_item_colon' => __('Parent Sections:'),
		'edit_item' => __('Edit Sections'),
		'update_item' => __('Update Sections'),
		'add_new_item' => __('Add New Sections'),
		'new_item_name' => __('New Sections Name'),
		'menu_name' => __('Sections'),);
		$args = array('hierarchical' => true, // make it hierarchical (like categories)
		'labels' => $labels, 'show_ui' => true, 
		'show_admin_column' => true, 'query_var' => true, 
		'rewrite' => ['slug' => 'sections'],);
		register_taxonomy('sections', 'post', $args);
	}

}
add_action('init', 'conscent_register_taxonomy_sections');
?>