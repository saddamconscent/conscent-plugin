<?php
if ( ! function_exists( 'conscent_member_add_meta_box' ) ) {

    function conscent_member_add_meta_box() {
        //this will add the metabox for the member post type
        $screens = array('post');
        foreach ($screens as $screen) {
            add_meta_box('member_sectionid', esc_html__('Content Visibility', 'conscent-paywall'), 'conscent_member_meta_box_callback', $screen);
        }
    }
}
add_action('add_meta_boxes', 'conscent_member_add_meta_box');
/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
if ( ! function_exists( 'conscent_member_meta_box_callback' ) ) {

    function conscent_member_meta_box_callback($post) {
        // Add a nonce field so we can check for it later.
        wp_nonce_field('conscent_member_save_meta_box_data', 'member_meta_box_nonce');
        /*

    * Use get_post_meta() to retrieve an existing value

    * from the database and use the value for the form.

    */
        $value = get_post_meta($post->ID, 'Conscent_data', true);
        echo '<label for="Content Visibility">';
        echo esc_html__('Content Visibility(in Paragraph)', 'conscent-paywall');
        echo '</label> ';
        echo '<input type="text" id="Conscent_data" name="Conscent_data" value="' . esc_attr($value) . '" size="25" />';
    }

}
/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */

 if ( ! function_exists( 'conscent_member_save_meta_box_data' ) ) {

    function conscent_member_save_meta_box_data($post_id) {
        if (!isset($_POST['member_meta_box_nonce'])) {
            return;
        }
        if (!wp_verify_nonce($_POST['member_meta_box_nonce'], 'conscent_member_save_meta_box_data')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        // Check the user's permissions.
        if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
            if (!current_user_can('edit_page', $post_id)) {
                return;
            }
        } else {
            if (!current_user_can('edit_post', $post_id)) {
                return;
            }
        }
        if (!isset($_POST['Conscent_data'])) {
            return;
        }
        $Conscent_data = sanitize_text_field($_POST['Conscent_data']);
        $conscent_price = "";
        $conscent_duration = "";
        update_post_meta($post_id, 'conscent_duration', $conscent_duration);
        update_post_meta($post_id, 'conscent_price', $conscent_price);
        update_post_meta($post_id, 'Conscent_data', $Conscent_data);
    }

}
add_action('save_post', 'conscent_member_save_meta_box_data');
?>